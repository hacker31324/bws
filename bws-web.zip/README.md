```markdown
# Bulgaria Web Studio LTD — Ready static site (Neon Retro)

Какво има в тази папка:
- index.html — главната страница (Neon hero, портфолио, тестимониъли, контактна форма).
- styles.css — всички стилове за сайта.
- logo-neon.svg — SVG лого.
- favicon.svg — малък favicon (можеш да замениш).
- README.md — този файл.

Как да деплойнеш (бързо, без GitHub):

A) Netlify Drop (най-лесно)
1. Запази файловете в една папка (пример: bws-site/).
2. Отиди на https://app.netlify.com/drop
3. Влачи папката bws-site/ в прозореца — сайтът ще бъде деплойнат автоматично. SSL се добавя безплатно.
4. Netlify автоматично ще засече формата (data-netlify="true") и ще ти изпраща заявки. (Формите работят само на Netlify.)

B) Vercel ZIP import
1. Създай ZIP на папката: zip -r bws-site.zip bws-site
2. Отиди на https://vercel.com/new -> Import -> Upload ZIP
3. След завършване ще имаш live URL. Забележка: Netlify forms няма да работи на Vercel — използвай Formspree или свържи backend endpoint.

C) Вариант с CLI (без GitHub)
- Vercel CLI:
  npm i -g vercel
  vercel login
  cd path/to/bws-site
  vercel --prod

- Netlify CLI:
  npm i -g netlify-cli
  netlify login
  netlify deploy --dir=./ --prod

D) Качване на собствен хостинг чрез FTP
1. Архивирай всички файлове в bws-site.zip и разархивирай/качете в public_html чрез FileZilla или cPanel File Manager.

Как да персонализираш (бързо)
- Смени имейла: в index.html намери admin@bulgaria-web-studio.com и промени на твоя имейл.
- Смени име на фирмата: в <title> и в .glitch::before/::after съдържанието.
- Добави реални изображения в секцията портфолио вместо picsum.photos.

Бележки
- Netlify Forms ще записва заявки автоматично. Ако използваш Vercel, препоръчвам Formspree (https://formspree.io) или собствен API.
- Ако искаш, мога да ти направя ZIP-а и да ти го върна тук, или да го zip-на и дам директна връзка за сваляне.
```